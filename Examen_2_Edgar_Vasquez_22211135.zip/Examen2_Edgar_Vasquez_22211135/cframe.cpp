#include "cframe.h"
#include "ui_cframe.h"


Cframe::Cframe(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Cframe)
{
    ui->setupUi(this);
    datosPredefinidos = {
        "Juan",
                "María",
                "Pedro",
                "Ana"
        };
}

Cframe::~Cframe()
{
    delete ui;
}


void Cframe::on_pushButton_clicked()
{
 ui->stackedWidget->setCurrentIndex(0);
}


void Cframe::on_pushButton_2_clicked()
{
 ui->stackedWidget->setCurrentIndex(1);
}


void Cframe::on_pushButton_3_clicked()
{
 ui->stackedWidget->setCurrentIndex(2);
}


void Cframe::on_pushButton_4_clicked()
{
 ui->stackedWidget->setCurrentIndex(3);
}


void Cframe::on_pushButton_5_clicked()
{
 ui->stackedWidget->setCurrentIndex(4);
}


void Cframe::on_pushButton_6_clicked()
{
 ui->stackedWidget->setCurrentIndex(5);
}




void Cframe::on_BtnDatos_clicked()
{
    ui->MostrarDatos->clear();
        // Mostrar solo los primeros cuatro datos predefinidos
        for (int i = 0; i < std::min(static_cast<int>(datosPredefinidos.size()), 4); ++i) {
            ui->MostrarDatos->append(datosPredefinidos[i]);
        }
}



void Cframe::on_Btnguardarinfo_clicked()
{
  guardarDatos();
}
void Cframe::guardarDatos()
{

    QString nombre = ui->textEdit_2->toPlainText(); // Obtener nombre desde textEdit_2
        QString yearFundacion = ui->textEdit->toPlainText(); // Obtener year de fundacion desde textEdit
        int flotaVehiculos = ui->spinBox->value(); // Obtener flota de vehiculos desde spinBox
        QString datosPredefinidos = ui->MostrarDatos->toPlainText(); // Obtener datos predefinidos desde MostrarDatos

        // Abrir un archivo para escritura (se crea si no existe)
        QFile file("datos_agencias.txt");
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            QMessageBox::critical(this, "Error", "No se pudo abrir el archivo para escribir");
            return;
        }

        // Crear un stream de texto para escribir en el archivo
        QTextStream out(&file);

        // Escribir los datos en el archivo
        out << "Nombre: " << nombre << "\n";
        out << "Año de fundación: " << yearFundacion << "\n";
        out << "Flota de vehículos: " << flotaVehiculos << "\n\n";
        out << "Datos Predefinidos:\n" << datosPredefinidos;

        // Cerrar el archivo
        file.close();

        QMessageBox::information(this, "Guardado", "Los datos se han guardado correctamente en datos_agencias.txt.");
}


void Cframe::on_pushButton_7_clicked()
{
      /*
    QString filePath = QFileDialog::getSaveFileName(this, tr("Guardar como"), "", tr("Archivos Excel (*.xlsx)"));
       if (filePath.isEmpty()) {
           return; // El usuario canceló la selección del archivo
       }

       QXlsx::Document xlsx;
       QXlsx::Worksheet *worksheet = xlsx.currentWorksheet();

       // Escribir los encabezados
       worksheet->write("A1", "Nombre");
       worksheet->write("B1", "Año de fundación");
       worksheet->write("C1", "Flota de vehículos");
       worksheet->write("D1", "Datos Predefinidos");

       // Obtener datos de los controles del formulario
       QString nombre = ui->textEdit_2->toPlainText();
       QString yearFundacion = ui->textEdit->toPlainText();
       int flotaVehiculos = ui->spinBox->value();
       QString datosPredefinidos = ui->MostrarDatos->toPlainText();

       // Escribir datos en Excel
       worksheet->write("A2", nombre);
       worksheet->write("B2", yearFundacion);
       worksheet->write("C2", flotaVehiculos);
       worksheet->write("D2", datosPredefinidos);

       // Guardar el archivo Excel
       if (xlsx.saveAs(filePath)) {
           QMessageBox::information(this, "Exportar a Excel", "Los datos se han exportado correctamente.");
       } else {
           QMessageBox::critical(this, "Error", "No se pudo exportar a Excel.");
       }
       */
}

