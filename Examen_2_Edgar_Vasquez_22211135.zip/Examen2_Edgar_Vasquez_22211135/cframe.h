
#ifndef CFRAME_H
#define CFRAME_H

#include <QMainWindow>
#include <vector>   // Para usar std::vector
#include <QString>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>

QT_BEGIN_NAMESPACE
namespace Ui { class Cframe; }
QT_END_NAMESPACE

class Cframe : public QMainWindow
{
    Q_OBJECT

public:
    Cframe(QWidget *parent = nullptr);
    ~Cframe();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

    void on_BtnDatos_clicked();

    void on_Btnguardarinfo_clicked();

    void on_pushButton_7_clicked();

private:
    Ui::Cframe *ui;
   std::vector<QString> datosPredefinidos;

        void mostrarDatosPredefinidos();
        void guardarDatos();
};
#endif // CFRAME_H
